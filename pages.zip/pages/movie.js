import Head from "next/head";
import { withRouter } from "next/router";

export default () => <div>hi!!!</div>;
